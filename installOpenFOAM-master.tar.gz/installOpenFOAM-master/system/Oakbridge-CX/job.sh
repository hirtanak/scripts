#!/bin/sh

MAX_QUEUE=32

cd /work/$(id -gn)/$(id -un)/OpenFOAM/installOpenFOAM

options=""
n=1
while [ $n -le $MAX_QUEUE ]
do
    command="pjsub \
--step \
$options \
-g $(id -gn) \
-L rscgrp=short \
-L node=1 \
-L elapse=04:00:00 \
-S \
system/Oakbridge-CX/jobScript"
  echo $command
  output=`$command`
  echo $output
  jid=`expr "$output" : '.* Job \([0-9]*\)_'`
  options="--sparam jid=$jid"
  n=`expr $n + 1`
done
