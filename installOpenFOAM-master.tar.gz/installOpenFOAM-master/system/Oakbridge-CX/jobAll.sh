#!/bin/sh

cd /work/$(id -gn)/$(id -un)/OpenFOAM/installOpenFOAM

for OpenFOAM_VERSION in \
2.3.0 \
2.3.1 \
2.4.0 \
3.0.0 \
3.0.1 \
4.0 \
v3.0+ \
4.1 \
v1606+ \
v1612+ \
v1706 \
5.0 \
v1712 \
v1806 \
v1812 \
6 \
7 \
OpenFOAM-v1906 \

do
    echo "./install.sh 'OpenFOAM_VERSION=OpenFOAM-${OpenFOAM_VERSION},COMPILER_TYPE=system,COMPILER=Icc.*'" | \
pjsub \
-g $(id -gn) \
-L rscgrp=small \
-L node=1 \
-L elapse=24:00:00 \
-S \
-N "OpenFOAM-${OpenFOAM_VERSION}"
done
