#!/bin/sh

MAX_QUEUE=4

OpenFOAM_BUILD_OPTION_LIST=(
'.*OpenFOAM-2.3.0.*'
'.*OpenFOAM-2.3.1.*'
'.*OpenFOAM-2.4.0.*'
'.*OpenFOAM-3.0.0.*'
'.*OpenFOAM-3.0.1.*'
'.*OpenFOAM-v3.0.*'
'.*OpenFOAM-4.0.*'
'.*OpenFOAM-4.1.*'
'.*OpenFOAM-5.0.*'
'.*OpenFOAM-v1606.*'
'.*OpenFOAM-v1612.*'
'.*OpenFOAM-v1706.*'
'.*OpenFOAM-v1712.*'
'.*OpenFOAM-v1806.*'
'.*OpenFOAM-6.*'
)

cd /lustre/$(id -gn)/$(id -un)/OpenFOAM/installOpenFOAM

itarget=1
for OpenFOAM_BUILD_OPTION in ${OpenFOAM_BUILD_OPTION_LIST[@]}
do
    jobScript=jobScript.$itarget
    cat > $jobScript <<EOF
#!/bin/bash
#PBS -N $jobScript
#PBS -q u-debug
#PBS -l walltime=0:30:00
#PBS -l select=1:mpiprocs=36

cd \$PBS_O_WORKDIR

./install.sh \
$OpenFOAM_BUILD_OPTION \
>& log.install.sh.\$PBS_JOBID
EOF

    options=""
    n=1
    while [ $n -le $MAX_QUEUE ]
    do
	command="qsub -W group_list=$(id -gn) $options $jobScript"
	echo $command
	id=`$command`
	echo $id
	options="-W depend=afterany:$id"
	n=`expr $n + 1`
    done
    itarget=`expr $itarget + 1`
done
