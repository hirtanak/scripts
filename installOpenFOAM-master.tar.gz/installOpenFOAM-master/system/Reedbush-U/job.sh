#!/bin/sh

MAX_QUEUE=8

cd /lustre/$(id -gn)/$(id -un)/OpenFOAM/installOpenFOAM

options=""
n=1
while [ $n -le $MAX_QUEUE ]
do
    command="qsub -W group_list=$(id -gn) $options system/Reedbush-U/jobScript"
    echo $command
    id=`$command`
    echo $id
    options="-W depend=afterany:$id"
    n=`expr $n + 1`
done
