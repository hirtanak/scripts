#!/bin/sh

MAX_QUEUE=5

options=""
n=1
while [ $n -le $MAX_QUEUE ]
do
    command="sbatch $options system/FOCUS/jobScript"
    echo $command
    id=`$command`
    echo $id
    options="-d afterany:$id"
    n=`expr $n + 1`
done
