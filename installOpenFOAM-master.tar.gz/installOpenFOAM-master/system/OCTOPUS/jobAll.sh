#!/bin/sh

OpenFOAM_BUILD_OPTION_LIST=(
'.*OpenFOAM-2.3.0,.*'
'.*OpenFOAM-2.3.1,.*'
'.*OpenFOAM-2.4.0,.*'
'.*OpenFOAM-3.0.0,.*'
'.*OpenFOAM-3.0.1,.*'
'.*OpenFOAM-v3.0+,.*'
'.*OpenFOAM-4.0,.*'
'.*OpenFOAM-4.1,.*'
'.*OpenFOAM-5.0,.*'
'.*OpenFOAM-v1606+,.*'
'.*OpenFOAM-v1612+,.*'
'.*OpenFOAM-v1706,.*'
'.*OpenFOAM-v1712,.*'
'.*OpenFOAM-v1806,.*'
'.*OpenFOAM-6,.*'
)

itarget=1
for OpenFOAM_BUILD_OPTION in ${OpenFOAM_BUILD_OPTION_LIST[@]}
do
    jobScript=jobScript.$itarget
    cat > $jobScript <<EOF
#!/bin/bash
#PBS -q OCTPHI
#PBS -l elapstim_req=12:00:00
#PBS -l cpunum_job=64
#PBS -b 1

cd \$PBS_O_WORKDIR

./install.sh \
$OpenFOAM_BUILD_OPTION \
>& log.install.sh.\$PBS_JOBID
EOF

    command="qsub $jobScript"
    echo $command
    $command
    itarget=`expr $itarget + 1`
done
