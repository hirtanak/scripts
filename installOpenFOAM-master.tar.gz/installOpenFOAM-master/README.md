## これは何か
スーパーコンピュータのように管理者権限が無いシステム上で，指定したバージョンのOpenFOAMと，依存するソフトウェアを自動的にソースからビルドしてインストールするbashスクリプト

---

### OpenFOAMのソースからのビルドは面倒
- OpenFOAMをビルドするにはcmake, flex, boost, Gccコンパイラ, GMP, MPFR, MPIライブラリなどの依存ソフトウェアが必要
- 依存ソフトウェアがシステムに無い時，ソースからビルドする必要が生じる
- 種々の依存ソフトウェアのバージョン制限を考え，適切なバージョンのソースをダウンロードし，適切な順序でビルドしていくのは面倒

---

### 自動ビルドスクリプトの特徴
- installOpenFOAMは単なるbashスクリプト
  - 管理者権限が不要なパッケージ管理システムとしては，Linux版であるLinuxbrewがあるが，rubyで記述されており，rubyのビルドも必要となる・・・
- ソースを自動でダウンロード
  - OpenFOAM，ThirdParty，依存ソフトのソースを自動ダウンロード
  - downloadディレクトリに予めインストールファイルを置いておけば，ダウンロード不可の計算機でもOK
- 依存ソフトウェアのバージョンの指定に応じて， foamConfigurePathsを用いて各種設定ファイルを変更
- コンパイラやMPIライブラリのバージョン毎にバイナリをビルド
- ビルドした依存ソフトウェアの再利用
  - 異なるOpenFOAMのバージョンにおいて既にビルドした依存ソフトウェアが見付かった場合には，シンボリックリンクを貼る(-lオプション)，もしくはコピーする(-cオプション)．ただし，デフォルトでは再ビルドを行う

---

### コンパイラやMPIライブラリのバージョン毎にバイナリをビルド

- 元々環境変数WM_COMPILERにコンパイラを指定できる(Gcc, Gcc48, Gcc49, ...)
  - wmakeのルールを修正し，バージョン番号の"."を"\_"に変換して付加して与えられるようにした
  - 自動的に指定バージョンのコンパイラを用いるようにした
  - コンパイラのバージョン毎にビルドバイナリの保存先を分けた
- MPIライブラリ(WM_MPLIB)についても同様
  - 通常はINTELMPIのように，バージョン番号までは与えない
  - INTEL2018_1_163のように指定することにより，ビルド・実行時に使用するバージョンを切り替えらえるようにした

---

## 設定ファイル
- [etc/system](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/etc/system) : ホスト名からシステムの判別設定
- [etc/url](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/etc/url) : ダウンロードURLの設定
- [etc/version](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/etc/version) : ソフトウェアバージョンの設定
- system/システム名/settings : 各システム別のコンパイラやMPIライブラリの設定
- system/システム名/bashrc : OpenFOAMバージョン，COMPILER，MPLIB等の組み合わせ設定
- system/システム名/url : 各システム独自のurl(オプション)
- system/システム名/version : 各システム独自のversion(オプション)

---

### [etc/system](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/etc/system) 

ポスト名からシステム名の自動判別を行うbashスクリプト．以下のシステムは設定済．

  - default(通常のLinuxマシン)
  - FOCUS (計算科学振興財団)
  - Reedbush-U (東京大学)
  - Oakforest-PACS (JCAHPC)
  - ITO (九州大学)
  - OCTOPUS (大阪大学)

---

### [etc/url](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/etc/url)

OpenFOAMのビルドに必要となるソフトウェアのダウンロードURLを設定するbashスクリプト

---

### [etc/version](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/etc/version)
ThirdPartyのソフトウェアバージョンを設定しているbashスクリプト

---

### system/システム名/settings

各システム用にコンパイラやMPIライブラリの設定をしているbashスクリプト


---

### system/システム名/bashrc

システム毎のインストール設定を行うbashスクリプト

```
# OpenFOAM install directory                                                                                            
FOAM_INST_DIR=${HOME}/OpenFOAM

# Download Only                                                                                                         
unset DOWNLOAD_ONLY
#DOWNLOAD_ONLY=yes                                                                                                      

# Number of processors                                                                                                  
export WM_NCOMPPROCS=1

# OpenFOAM version list to install                                                                                      
OpenFOAM_BUILD_OPTION_LIST=(
    OpenFOAM_VERSION=OpenFOAM-v1712,BUILD_PARAVIEW=0\
,COMPILER_TYPE=ThirdParty,COMPILER=Gcc4_8_5,MPLIB=OPENMPI\
,COMPILE_OPTION=Opt,ARCH_OPTION=64,PRECISION_OPTION=DP,LABEL_SIZE=32
)
```

- ```FOAM_INST_DIR``` : OpenFOAMをインストールするディレクトリ
- ```DOWNLOAD_ONLY``` : ダウンロードのみの時は何からの値を設定する
- ```WM_NCOMPPROCS``` : ビルド時の並列数
- ```OpenFOAM_BUILD_OPTION_LIST``` : ビルド設定組み合わせ
    - OpenFOAM_VERSION: OpenFOAMバージョン
    - BUILD_PARAVIEW: ParaViewのビルド有無(1 or 0)
    - ビルド設定(OpenFOAMのetc/bashrc内の環境変数からWM_を除いたもの)
        - COMPILER_TYPE: コンパイラのインストール種別(system or ThirdParty)
        - COMPILER: コンパイラ(Gcc*, Icc*など)
        - MPLIB: MPIライブラリ(OPENMPI, INTELMPI*など)
        - その他: ビルド時の詳細設定
    - 実際にビルドする組み合わせはオプションで指定可能

---

## 一般的なビルド方法

### OpenFOAM用ディレクトリの作成

- 以下では```$HOME/OpenFOAM``` にOpenFOAMをインストールすると仮定

```bash
mkdir $HOME/OpenFOAM
```

### レポジトリの取得

```bash
cd $HOME/OpenFOAM
git clone https://gitlab.com/OpenCAE/installOpenFOAM.git
```
### 設定ファイルの変更

---

### ビルド

```
./install.sh '.*OpenFOAM-v1612.*Gcc4_8_5.*'
```

- 引数には```system/システム名/bashrc```におけるOpenFOAM_BUILD_OPTION_LIST配列で定義しているビルドするバージョンが指定可
- 引数がOpenFOAM_BUILD_OPTION_LIST配列の要素とのマッチにはexprコマンドを用いているため，上記の例のように正規表現で記述することが可能
- 引数を指定しないと，OpenFOAM_BUILD_OPTION_LIST配列で定義した全てのバージョンをビルド

---

### インストールしたビルドバージョンの環境設定

'.'(ドット)またはsourceコマンドを用いて，install.shを-sオプションを付きで実行すると，引数で指定したバージョンのOpenFOAMの環境設定のみを行う．

```
. $HOME/OpenFOAM/installOpenFOAM/install.sh -s '.*OpenFOAM-v1612.*Gcc4_8_5.*'
```

---

## FOCUSでのビルド方法

### FOCUSの特徴
- Reedbushのフロントエンドノードでは並列実行・コンパイルが禁止されており，また負荷がかかるプロセスも動作不可
- また，FOCUSでは計算ノードに限らず，フロントエンドノードとファイルのダウンロードが不可

### FOCUSでのOpenFOAMビルド方針
- インストールファイルのダウンロードは別のシステムで行い，ダウンロードディレクトリのdownload内のファイルをFOCUSにアップロード
- ログインノードではOpenFOAMやThirdPartyおよび依存ソフトウェアのインストールファイルのファイルの展開のみを行い，バッチジョブを用い計算ノードで並列ビルドを行う

---

### FOCUSでのOpenFOAM用ディレクトリの作成

- 既に```$HOME/OpenFOAM```のディレトリやファイルがある場合には，予め別名にするか別の場所に移動していおいてから以下を実行

```bash
mkdir $HOME/OpenFOAM
```

### FOCUSでのレポジトリの取得

```bash
cd $HOME/OpenFOAM
git clone https://gitlab.com/OpenCAE/installOpenFOAM.git
```

---

### FOCUSへのインストールファイルのアップロード

FOCUSでインストールファイルを置くディレクトリを作成．

```
cd installOpenFOAM
mkdir download
```

このディレクトリに，別システムでダウンロードしたインストールファイルをアップードする．

---

### FOCUSでのインストールファイルの展開


FOCUSのフロントエンドノードで```install.sh```を実行すると，ファイルの展開が行われる．

```
./install.sh '.*OpenFOAM-2.3.1.*Gcc4_8_5.*'
```

install.shの引数には[system/FOCUS/bashrc](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/system/FOCUS/bashrc)におけるOpenFOAM_BUILD_OPTION_LIST配列で定義しているビルドするバージョンを指定．

---

### FOCUSでのバッチジョブでのビルド

```bash
sbatch system/FOCUS/jobScript
```

- 予め[system/FOCUS/jobScript](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/system/FOCUS/jobScript)の内容をビルドするバージョン用に書き変えてから，ジョブを投入する．
- バッチジョブによリノードが持つコア数でビルドする．
- ただし，上記のjobScriptではすぐに実行できるよう，debugキューを指定しており，debugキューの最大経過時間30分を指定しているので，1回の実行ではビルドが完了しない可能性がある．
- そこで，ビルドが終了するまで上記を何回か繰り返す必要がある．

---

### FOCUSでのチェーンジョブでのビルド

```bash
system/FOCUS/job.sh
```

- チェーンジョブを用いて後続ジョブを自動投入するには，上記のスクリプトを実行する．
- なお，job.sh内の最大投入ジョブ数(MAX_QUEUE)は適宜変更．

---

### FOCUSでの環境設定

例えば以下のようにする．

```
. $HOME/OpenFOAM/installOpenFOAM/install.sh -s '.*OpenFOAM-2.3.1.*Gcc4_8_5.*'
```

----

## Reedbush-Uでのビルド方法

### Reedbush-Uの特徴
- Reedbushのログインノードでは並列実行・コンパイルが禁止されており，また負荷がかかるプロセスも動作不可．
- また，計算ノードではファイルのダウンロードが不可．

----

### Reedbush-UでのOpenFOAMビルド方針

- ログインノードではOpenFOAMやThirdPartyおよび依存ソフトウェアのインストールファイルのダウンロードとファイルの展開のみを行い，バッチジョブを用い36コアの計算ノードで最大36並列の並列ビルドを行う．
- また，Reedbushでは計算ノードから参照できるよう，OpenFOAMをlustreファイルシステムにインストールする必要がある．
- しかし，ログインノードからは通常通り```$HOME/OpenFOAM```として参照できるほうが便利．
- 従って，ここでは，OpenFOAMはlustreファイルシステム内の計算データ用領域である```/lustre/グループ名/ユーザー名/OpenFOAM```にインストールし，```$HOME/OpenFOAM```からシンボリックリンクを貼る．

---

### Reedbush-UでのOpenFOAM用ディレクトリの作成

- 既に```$HOME/OpenFOAM```のディレトリやファイルがある場合には，予め別名にするか別の場所に移動していおいてから以下を実行．

```bash
mkdir /lustre/$(id -gn)/$(id -un)/OpenFOAM
```

### Reedbush-Uでのhomeファイルシステムからのリンク作成

```bash
ln -s /lustre/$(id -gn)/$(id -un)/OpenFOAM $HOME/OpenFOAM
```

### Reedbush-Uでのレポジトリの取得

```bash
cd /lustre/$(id -gn)/$(id -un)/OpenFOAM
git clone https://gitlab.com/OpenCAE/installOpenFOAM.git
```

---

### Reedbush-Uでのインストールファイルのダウンロードと展開

Reedbushのログインノードで```install.sh```を実行すると，ファイルのダウンロードと展開のみが行われる．

```
cd installOpenFOAM
./install.sh '.*OpenFOAM-2.3.1.*Gcc4_8_5.*'
```

install.shの引数には[system/Reedbush-U/bashrc](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/system/Reedbush-U/bashrc)におけるOpenFOAM_BUILD_OPTION_LIST配列で定義しているビルドするバージョンを指定する．

---

### Reedbush-Uでのバッチジョブでのビルド

```bash
qsub -W group_list=グループ名 system/Reedbush-U/jobScript
```

- 予め[system/Reedbush-U/jobScript](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/system/Reedbush-U/jobScript)の内容をビルドするバージョン用に書き変えてから，ジョブを投入する．
- バッチジョブによリ1ノード36並列でビルドする．
- ただし，上記のjobScriptではすぐに実行できるよう，debugキューを指定しており，debugキューの最大経過時間30分を指定しているので，1回の実行ではビルドが完了しない可能性がある．
- そこで，ビルドが終了するまで上記を何回か繰り返す必要がある．

---

### Reedbush-Uでのチェーンジョブでのビルド

```bash
system/Reedbush-U/job.sh
```

- チェーンジョブを用いて後続ジョブを自動投入するには，上記のスクリプトを実行する．
- なお，job.sh内の最大投入ジョブ数(MAX_QUEUE)は適宜変更する．

---

### Reedbush-Uでの環境設定

例えば以下のようにする．

```
. /lustre/$(id -gn)/$(id -un)/OpenFOAM/installOpenFOAM/install.sh -s '.*OpenFOAM-2.3.1.*Gcc4_8_5.*'
```

---

## Oakforest-PACSでのビルド方法

### Oakforest-PACSの特徴

- Oakforest-PACSのログインノード(CPU: Intel Xeon CPU E5-2690 v4, Broadwell, 2.60GHz)では並列実行・コンパイルが禁止されており，また負荷がかかるプロセスも動作不可．
- また，計算ノードではファイルのダウンロードが不可．
- さらに，コア単体性能が低いXeon Phiの計算ノードでビルドするのは効率が悪い．

---

### Oakforest-PACSでのOpenFOAMビルド方針

- ログインノードではOpenFOAMやThirdPartyおよび依存ソフトウェアのインストールファイルのダウンロードとファイルの展開のみを行い，ログインノードとCPUが同じであるprepostのインタラクティブキューを用い最大28並列の並列ビルドを行う．
- また，Oakforest-PACSでは計算ノードから参照できるよう，OpenFOAMをworkファイルシステムにインストールする必要がある．
- しかし，ログインノードからは通常通り```$HOME/OpenFOAM```として参照できるほうが便利．
- 従って，ここでは，OpenFOAMはworkファイルシステム内の計算データ用領域である```/work/グループ名/ユーザー名/OpenFOAM```にインストールし，```$HOME/OpenFOAM```からシンボリックリンクを貼る．

---

### OpenFOAM用ディレクトリの作成

- 既に```$HOME/OpenFOAM```のディレトリやファイルがある場合には，予め別名にするか別の場所に移動していおいてから以下を実行する．

```bash
mkdir /work/$(id -gn)/$(id -un)/OpenFOAM
```

### Homeファイルシステムからのリンク作成

```bash
ln -s /work/$(id -gn)/$(id -un)/OpenFOAM $HOME/OpenFOAM
```

### レポジトリの取得

```bash
cd /work/$(id -gn)/$(id -un)/OpenFOAM
git clone https://gitlab.com/OpenCAE/installOpenFOAM.git
```

---

### インストールファイルのダウンロードと展開

- Oakforest-PACSのログインノードで```install.sh```を実行すると，ファイルのダウンロードと展開のみが行われる．

```
cd installOpenFOAM
./install.sh '.*OpenFOAM-2.3.1.*Gcc4_8_5.*'
```

- install.shの引数には[system/Oakforest-PACS/bashrc](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/system/Oakforest-PACS/bashrc)におけるOpenFOAM_BUILD_OPTION_LIST配列で定義しているビルドするバージョンを指定する．

---

### prepostインタラクティブキューでのビルド

まず，prepostキューのインタラクティブジョブを実行する．もし，```id -gn```の結果と異なるグループ名を指定したい場合には，適宜変更する．なお，prepostキューではトークンは消費されない．

```bash
pjsub --interact -g $(id -gn) -L rscgrp=prepost --mpi proc=28
```

インタラクティブジョブが実行されて，prepost用のノードにログインしたら，通常通り```install.sh```をビルドすると，最大28並列でビルドする．

```bash
./install.sh '.*OpenFOAM-2.3.1.*Gcc4_8_5.*' >& log.install.sh &
tail -f log.install.sh
```

prepostキューの最大経過時間は6時間ですが，制限時間内に途中終了した場合には，prepostキューのインタラクティブジョブを実行から再度やり直す．

---

### 環境設定

例えば以下のようにする．

```
. /work/$(id -gn)/$(id -un)/OpenFOAM/installOpenFOAM/install.sh -s '.*OpenFOAM-2.3.1.*Gcc4_8_5.*'
```

---

## OCTOPUSでのビルド方法

### OCTOPUSの特徴

- OCTOPUSのログインノード(CPU: Intel Xeon Gold 6126 CPU, 2.60GHz)では並列実行・コンパイルが禁止されており，また負荷がかかるプロセスも動作不可．
- また，計算ノードではファイルのダウンロードが不可．
- さらに，計算ノードにはflexがインストールされていないので，一部のライブラリのコンパイルが失敗する(2018年8月1日現在)．

---

### OCTOPUSでのOpenFOAMビルド方針

- 計算ノードのみではビルドができないので，時間はかかるがログインノードのみでコンパイルする．
- OCTOPUSのhomeファイルシステムの容量は100GBと少ないので，workファイルシステムにインストールする．
- しかし，ログインノードからは通常通り```$HOME/OpenFOAM```として参照できるほうが便利．
- 従って，ここでは，OpenFOAMはworkファイルシステム内の計算データ用領域である```/octfs/work/グループ名/ユーザー名/OpenFOAM```にインストールし，```$HOME/OpenFOAM```からシンボリックリンクを貼る．
- OpenFOAM-2.3.0〜3.0.1，v3.0+〜1606+では，Intel Compilerを用いる場合，c/C++コンパイラーの最適化オプションに，搭載されているCPUを調べ、最適なベクトル化オプションを自動的に選択する```-xHost```が付加されているため，Intel Xeon Goldのログインノードにおいてコンパイルすると，Gold用のバイナリが生成され，Xeon Phiノードで動作しない．このため，```-xHost```オプションを削除してコンパイルする．

---

### OpenFOAM用ディレクトリの作成

- 既に```$HOME/OpenFOAM```のディレトリやファイルがある場合には，予め別名にするか別の場所に移動していおいてから以下を実行する．

```bash
mkdir /octfs/work/$(id -gn)/$(id -un)/OpenFOAM
```

### Homeファイルシステムからのリンク作成

```bash
ln -s /octfs/work/$(id -gn)/$(id -un)/OpenFOAM $HOME/OpenFOAM
```

### レポジトリの取得

```bash
cd /octfs/work/$(id -gn)/$(id -un)/OpenFOAM
git clone https://gitlab.com/OpenCAE/installOpenFOAM.git
```

---

### ログインノードでのビルド

- OCTOPUSのログインノードで```install.sh```を実行する．
- install.shの引数には[system/OCTOPUS/bashrc](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/system/OCTOPUS/bashrc)におけるOpenFOAM_BUILD_OPTION_LIST配列で定義しているビルドするバージョンを指定する．
- ```-r```または```--remove-xHost```オプションを指定して，Intel Compiler用の最適化オプション```-xHost```を除去する．

```bash
cd installOpenFOAM
./install.sh -r '.*OpenFOAM-2.3.1.*' >& log.install.sh &
tail -f log.install.sh
```

---

### 環境設定

例えば以下のようにする．

```bash
. /octfs/work/$(id -gn)/$(id -un)/OpenFOAM/installOpenFOAM/install.sh -s '.*OpenFOAM-2.3.1.*'
```

---

## ITOでのビルド方法

### ITOの特徴
- 計算ノードでもファイルのダウンロードが可能

## ITOでのOpenFOAMビルド方針
- バッチジョブを用い計算ノードで並列ビルドを行う
- バッチジョブでのビルドではエラーが出る場合や，ジョブが混雑している場合にはログインノードでビルドする

---

### OpenFOAM用ディレクトリの作成

```bash
mkdir ~/OpenFOAM
```

### レポジトリの取得

```bash
cd ~/OpenFOAM
git clone https://gitlab.com/OpenCAE/installOpenFOAM.git
```

---

### ログインノードでのビルド

- ITOのログインノードで```install.sh```を実行する．
- install.shの引数には[system/ITO/bashrc](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/system/ITO/bashrc)におけるOpenFOAM_BUILD_OPTION_LIST配列で定義しているビルドするバージョンを指定する


例えば以下のようにする．
```bash
cd ~/OpenFOAM/installOpenFOAM
./install.sh OpenFOAM_VERSION=OpenFOAM-2.3.0,COMPILER_TYPE=system,COMPILER=Gcc4_8_5,COMPILE_OPTION=Opt,ARCH_OPTION=64,PRECISION_OPTION=DP,LABEL_SIZE=32,MPLIB=INTELMPI2018_3_222 >& log.install.sh &
Tail -f log.install.sh
```

---

### ITOでのバッチジョブでのビルド

- 予め[system/ITO/jobScript](https://gitlab.com/OpenCAE/installOpenFOAM/blob/master/system/ITO/jobScript)の内容をビルドするバージョン用に書き変えてから，ジョブを投入する．
- バッチジョブによリ1ノード36並列でビルドする．

```bash
pjsub system/ITO/jobScript
```

---

### 環境設定

例えば以下のようにする．

```bash
. ~/OpenFOAM/installOpenFOAM/install.sh -s OpenFOAM_VERSION=OpenFOAM-2.3.0,COMPILER_TYPE=system,COMPILER=Gcc4_8_5,COMPILE_OPTION=Opt,ARCH_OPTION=64,PRECISION_OPTION=DP,LABEL_SIZE=32,MPLIB=INTELMPI2018_3_222
```
